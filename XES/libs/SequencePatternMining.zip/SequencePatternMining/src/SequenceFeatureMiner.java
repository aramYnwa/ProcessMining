import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.deckfour.xes.model.impl.XLogImpl;
import org.processmining.plugins.signaturediscovery.DiscoverSignatures;
import org.processmining.plugins.signaturediscovery.OpenLogFilePlugin;
import org.processmining.plugins.signaturediscovery.SignatureDiscoveryInput;
import org.processmining.plugins.signaturediscovery.types.FeatureType;


public class SequenceFeatureMiner {
	
	/**
	 * 1st argument: support level (real number)
	 * 2nd argument: coverage threshold (integer)
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String, String> featureMap = new HashMap<String, String>();
		featureMap.put("TR", "Tandem Repeat");
		featureMap.put("MR", "Maximal Repeat");
		featureMap.put("TRA", "Tandem Repeat Alphabet");
		featureMap.put("MRA", "Maximal Repeat Alphabet");
		
		Map<String, FeatureType> featureTypeMap = new HashMap<String, FeatureType>();
		featureTypeMap.put("TR", FeatureType.Sequence);
		featureTypeMap.put("MR", FeatureType.Sequence);
		featureTypeMap.put("TRA", FeatureType.Alphabet);
		featureTypeMap.put("MRA", FeatureType.Alphabet);
		
        try {
    		double min_sup = Double.valueOf(args[0]);
    		int coverage_thres = Integer.valueOf(args[1]);
    		
    		//Find feature type from the current directory path
    		String featureType;
    		String featureString = "MR/TR/MRA/TRA";
    		File file = new File(System.getProperty("user.dir"));
    		while (file != null && !file.getName().equals("") && !featureString.contains(file.getName())) {
    			file = file.getParentFile();
    		}
    		if (file != null && !file.getName().equals("")) {
    			featureType = file.getName();
    			System.out.println("Feature Type: " + featureType);
    		}
    		else {
    			System.out.println("Cannot locate the feature type from the current directory!!! Stop here.");
    			return;
    		}    		
    		
        	System.out.println("Import event log files. Expect two files: training.xes and testing.xes");
        	OpenLogFilePlugin logImporter = new OpenLogFilePlugin();
        	File trainFile = new File(System.getProperty("user.dir") + "\\training.xes");
			XLog trainLog = (XLog)logImporter.importFile(trainFile);

        	File testFile = new File(System.getProperty("user.dir") + "\\testing.xes");
        	XLog testLog;
        	try {
        		testLog = (XLog)logImporter.importFile(testFile);
        	}
        	catch (Exception e) {
        		testLog = null;
        	}
			
			SignatureDiscoveryInput input = new SignatureDiscoveryInput();
			input.addFeature(featureMap.get(featureType));
			input.setBaseFeatures(true);
			input.setFeatureCombination("All");
			input.setFeatureType(featureTypeMap.get(featureType));
			input.setNominalCount(false);
			
			System.out.println("Start feature mining & selection, min_sup:" + min_sup + ", coverage:" + coverage_thres);
			System.out.println("Current directory: " + System.getProperty("user.dir"));
			long start = System.currentTimeMillis();
			
			DiscoverSignatures plugin = new DiscoverSignatures(trainLog, testLog, min_sup, coverage_thres, input, true);
			
			System.out.println("Run-time (seconds): " + 1.0*(System.currentTimeMillis() - start)/1000);
			FileWriter fileWriter = new FileWriter(System.getProperty("user.dir") + "\\run-time.txt");
			fileWriter.write("Run-time: " + 1.0*(System.currentTimeMillis() - start)/1000 + " seconds.");		
			fileWriter.flush();
			fileWriter.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
