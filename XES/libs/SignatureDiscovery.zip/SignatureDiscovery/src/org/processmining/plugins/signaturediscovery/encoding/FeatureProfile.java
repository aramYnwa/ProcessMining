package org.processmining.plugins.signaturediscovery.encoding;

/**
 * Represent one feature
 * @author Bruce
 * @Create 26 May 2015
 *
 */
public class FeatureProfile {
	
}
