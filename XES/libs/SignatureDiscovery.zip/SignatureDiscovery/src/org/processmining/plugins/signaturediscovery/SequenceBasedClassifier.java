package org.processmining.plugins.signaturediscovery;

public class SequenceBasedClassifier {

}
